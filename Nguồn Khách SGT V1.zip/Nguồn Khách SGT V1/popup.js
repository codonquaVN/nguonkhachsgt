document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('copyButton').addEventListener('click', copyText);
    handleField1Change(); // Khởi tạo trạng thái khi tải trang
    loadProducts(); // Load dữ liệu sản phẩm
});

function handleField1Change() {
    const field1 = document.getElementById('field1').value;
    const isKWM = (field1 === 'KWM');
    
    const field2 = document.getElementById('field2');
    const field3 = document.getElementById('field3');

    if (isKWM) {
        field2.disabled = false;
        field3.disabled = false;
    } else {
        field2.disabled = true;
        field3.disabled = true;
        field2.value = "";
        field3.value = "";
    }
}

function copyText() {
    const field1 = document.getElementById('field1').value;
    const field2 = document.getElementById('field2').value;
    const field3 = document.getElementById('field3').value;
    const note = document.getElementById('note').value;

    // Lấy giá trị radio
    let option = '';
    if (document.getElementById('btkOption').checked) option = 'BTK';
    if (document.getElementById('gklOption').checked) option = 'GKL';

    if (field1 === 'KWM' && (!field2 || !field3)) {
        alert('Vui lòng chọn đầy đủ Nguồn Khách và Kênh Tương Tác khi chọn KWM!');
        return;
    }

    let textToCopy = field1;

    if (field1 === 'KWM') {
        textToCopy += ` - ${field2} - ${field3}`;
    }

    // Thêm BTK hoặc GKL nếu có chọn
    if (option) {
        textToCopy += ` | ${option}`;
    }

    // Thêm ghi chú nếu có
    if (note) {
        textToCopy += ` | ${note}`;
    }

    navigator.clipboard.writeText(textToCopy).then(() => {
        alert('Đã sao chép: ' + textToCopy);
    }).catch(err => {
        console.error('Không thể sao chép', err);
    });
}

// Biến lưu trữ dữ liệu sản phẩm
let products = [];

// Hàm đọc file JSON
async function loadProducts() {
    try {
        const response = await fetch(chrome.runtime.getURL('products.json'));
        const data = await response.json();
        products = data.products;
        console.log('Đã tải dữ liệu sản phẩm:', products);
    } catch (error) {
        console.error('Lỗi khi đọc file JSON:', error);
    }
}

// Hàm tìm kiếm sản phẩm
function searchProducts(keyword) {
    if (!keyword || keyword.length < 2) return [];
    
    keyword = keyword.toLowerCase();
    return products.filter(product => 
        product.TenSanPham.toLowerCase().includes(keyword) ||
        product.SKU.toLowerCase().includes(keyword)
    );
}

// Hàm hiển thị kết quả tìm kiếm
function displayResults(results) {
    const resultsContainer = document.getElementById('skuResults');
    resultsContainer.innerHTML = '';
    
    if (results.length === 0) {
        resultsContainer.style.display = 'none';
        return;
    }

    results.forEach(product => {
        const div = document.createElement('div');
        div.className = 'sku-item';
        div.textContent = `${product.SKU} - ${product.TenSanPham}`;
        
        // Xử lý khi click vào kết quả
        div.onclick = () => {
            const sku = product.SKU;
            
            // Kiểm tra xem có element nào đang focus không
            const activeElement = document.activeElement;
            
            if (activeElement && (activeElement.tagName === 'INPUT' || activeElement.tagName === 'TEXTAREA')) {
                // Nếu có input/textarea đang focus, chèn SKU vào vị trí con trỏ
                const start = activeElement.selectionStart;
                const end = activeElement.selectionEnd;
                const value = activeElement.value;
                
                activeElement.value = value.substring(0, start) + sku + value.substring(end);
                
                // Di chuyển con trỏ về sau SKU vừa chèn
                activeElement.setSelectionRange(start + sku.length, start + sku.length);
                activeElement.focus();
            } else {
                // Nếu không có element nào focus, copy vào clipboard
                navigator.clipboard.writeText(sku).then(() => {
                    // Hiển thị thông báo nhỏ
                    const notification = document.createElement('div');
                    notification.textContent = 'Đã copy: ' + sku;
                    notification.style.position = 'fixed';
                    notification.style.bottom = '10px';
                    notification.style.left = '50%';
                    notification.style.transform = 'translateX(-50%)';
                    notification.style.backgroundColor = '#4CAF50';
                    notification.style.color = 'white';
                    notification.style.padding = '8px 16px';
                    notification.style.borderRadius = '4px';
                    notification.style.zIndex = '1000';
                    
                    document.body.appendChild(notification);
                    
                    // Xóa thông báo sau 2 giây
                    setTimeout(() => {
                        document.body.removeChild(notification);
                    }, 2000);
                });
            }
            
            // Đóng dropdown kết quả
            resultsContainer.style.display = 'none';
            
            // Xóa từ khóa tìm kiếm
            document.getElementById('skuSearch').value = '';
        };
        
        resultsContainer.appendChild(div);
    });

    resultsContainer.style.display = 'block';
}

// Xử lý sự kiện tìm kiếm
const searchInput = document.getElementById('skuSearch');
if (searchInput) {
    searchInput.addEventListener('input', (e) => {
        const keyword = e.target.value.trim();
        const results = searchProducts(keyword);
        displayResults(results);
    });
}

// Đóng kết quả tìm kiếm khi click ra ngoài
document.addEventListener('click', (e) => {
    const searchContainer = document.querySelector('.search-container');
    if (searchContainer && !searchContainer.contains(e.target)) {
        document.getElementById('skuResults').style.display = 'none';
    }
});