// Ẩn dropdown gợi ý của web (ví dụ class là .ant-select-dropdown)
const style = document.createElement('style');
style.innerHTML = `
  .ant-select-dropdown, .ant-select-dropdown-placement-bottomLeft, .ant-select-item-option-content {
    display: none !important;
  }
`;
document.head.appendChild(style);

/*
// --- ĐÃ VÔ HIỆU HÓA GỢI Ý SKU TRÊN WEB ---
let products = [];
let suggestionsBox = null;
let currentInput = null;
let selectedIndex = -1;

// Load products data
fetch(chrome.runtime.getURL('products.json'))
    .then(response => response.json())
    .then(data => {
        products = data.products;
    })
    .catch(error => console.error('Error loading products:', error));

// Create suggestions box
function createSuggestionsBox() {
    const box = document.createElement('div');
    box.className = 'sku-suggestions';
    box.style.display = 'none';
    document.body.appendChild(box);
    return box;
}

// Show suggestions
function showSuggestions(input) {
    if (!suggestionsBox) {
        suggestionsBox = createSuggestionsBox();
    }

    const rect = input.getBoundingClientRect();
    suggestionsBox.style.top = `${rect.bottom + window.scrollY}px`;
    suggestionsBox.style.left = `${rect.left + window.scrollX}px`;

    const keyword = input.value.toLowerCase();
    if (keyword.length < 2) {
        suggestionsBox.style.display = 'none';
        return;
    }

    const matches = products.filter(product =>
        product.SKU.toLowerCase().includes(keyword)
    );

    if (matches.length === 0) {
        suggestionsBox.style.display = 'none';
        return;
    }

    suggestionsBox.innerHTML = '';
    matches.forEach((product, index) => {
        const div = document.createElement('div');
        div.className = 'sku-suggestion-item';
        div.textContent = product.SKU;
        div.addEventListener('click', () => {
            insertSKU(input, product.SKU);
            hideSuggestions();
        });
        div.addEventListener('mouseover', () => {
            selectedIndex = index;
            updateSelection();
        });
        suggestionsBox.appendChild(div);
    });

    suggestionsBox.style.display = 'block';
}

// Insert SKU at cursor position
function insertSKU(input, sku) {
    const start = input.selectionStart;
    const end = input.selectionEnd;
    const text = input.value;
    input.value = text.substring(0, start) + sku + text.substring(end);
    input.setSelectionRange(start + sku.length, start + sku.length);
    input.focus();
}

// Hide suggestions
function hideSuggestions() {
    if (suggestionsBox) {
        suggestionsBox.style.display = 'none';
    }
    selectedIndex = -1;
}

// Update selected item
function updateSelection() {
    const items = suggestionsBox.getElementsByClassName('sku-suggestion-item');
    for (let i = 0; i < items.length; i++) {
        items[i].classList.toggle('selected', i === selectedIndex);
    }
}

// Handle keyboard navigation
function handleKeydown(e) {
    if (!suggestionsBox || suggestionsBox.style.display === 'none') return;

    const items = suggestionsBox.getElementsByClassName('sku-suggestion-item');
    
    switch (e.key) {
        case 'ArrowDown':
            e.preventDefault();
            selectedIndex = Math.min(selectedIndex + 1, items.length - 1);
            updateSelection();
            break;
        case 'ArrowUp':
            e.preventDefault();
            selectedIndex = Math.max(selectedIndex - 1, 0);
            updateSelection();
            break;
        case 'Enter':
            e.preventDefault();
            if (selectedIndex >= 0 && items[selectedIndex]) {
                insertSKU(currentInput, items[selectedIndex].textContent);
                hideSuggestions();
            }
            break;
        case 'Escape':
            hideSuggestions();
            break;
    }
}

// Add event listeners to all input and textarea elements
document.addEventListener('focusin', function(e) {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
        currentInput = e.target;
        currentInput.addEventListener('input', () => showSuggestions(currentInput));
        currentInput.addEventListener('keydown', handleKeydown);
    }
});

document.addEventListener('focusout', function(e) {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
        // Delay hiding to allow click events on suggestions
        setTimeout(hideSuggestions, 200);
    }
});

// Hide suggestions when clicking outside
document.addEventListener('click', function(e) {
    if (!e.target.closest('.sku-suggestions') && !e.target.closest('input') && !e.target.closest('textarea')) {
        hideSuggestions();
    }
}); 
*/ 