document.addEventListener('DOMContentLoaded', function() {
    const fileInput = document.getElementById('fileInput');
    const saveButton = document.getElementById('saveButton');
    const downloadTemplate = document.getElementById('downloadTemplate');
    const previewTable = document.getElementById('previewTable').getElementsByTagName('tbody')[0];
    
    let importedData = [];

    // Xử lý khi chọn file
    fileInput.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function(e) {
            const data = new Uint8Array(e.target.result);
            const workbook = XLSX.read(data, {type: 'array'});
            
            // Lấy sheet đầu tiên
            const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
            
            // Chuyển đổi sang JSON
            const jsonData = XLSX.utils.sheet_to_json(firstSheet);
            
            // Xử lý và hiển thị dữ liệu
            importedData = jsonData.map(row => ({
                SKU: row.SKU || row.sku || '',
                TenSanPham: row.SKU || row.sku || '' // Sử dụng SKU làm tên sản phẩm
            })).filter(item => item.SKU); // Lọc bỏ các dòng không có SKU

            displayPreview(importedData);
        };
        reader.readAsArrayBuffer(file);
    });

    // Hiển thị preview
    function displayPreview(data) {
        previewTable.innerHTML = '';
        data.forEach(item => {
            const row = previewTable.insertRow();
            row.insertCell(0).textContent = item.SKU;
            row.insertCell(1).textContent = item.TenSanPham;
        });
    }

    // Lưu dữ liệu
    saveButton.addEventListener('click', function() {
        if (importedData.length === 0) {
            alert('Vui lòng import dữ liệu trước khi lưu!');
            return;
        }

        const jsonContent = {
            products: importedData
        };

        // Tạo file JSON và tải về
        const blob = new Blob([JSON.stringify(jsonContent, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'products.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    });

    // Tải file mẫu
    downloadTemplate.addEventListener('click', function() {
        const template = [
            { SKU: 'T2514VBTB' },
            { SKU: 'FTKB35ZVMV MN' },
            { SKU: 'JC-09IU36 ML' }
        ];

        const ws = XLSX.utils.json_to_sheet(template);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'SKU Template');
        
        // Tải file Excel mẫu
        XLSX.writeFile(wb, 'sku_template.xlsx');
    });
}); 