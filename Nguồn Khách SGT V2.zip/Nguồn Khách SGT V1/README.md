# Chrome Extension - Format Text Generator

Extension Chrome giúp tạo và sao chép format text nhanh chóng theo cấu trúc định sẵn.

## Tính năng

- Tạo format text tự động dựa trên các lựa chọn
- Hỗ trợ nhiều loại format khác nhau (KWM, KWC, KLM, KLC)
- Tích hợp validation cho trường hợp KWM
- Giao diện người dùng thân thiện
- Sao chép nhanh chóng vào clipboard

## Cài đặt

1. Clone repository này về máy
2. Mở Chrome và truy cập `chrome://extensions/`
3. Bật "Developer mode" ở góc phải trên
4. Nhấn "Load unpacked" và chọn thư mục chứa extension

## Cách sử dụng

### Format KWM
1. Chọn "KWM" ở Field 1
2. Chọn Nguồn Khách (SGT/DTGR/DTMB/WSS)
3. Chọn Kênh Tương Tác (Call/OA/DW/FB)
4. Nhập ghi chú (nếu cần)
5. Nhấn Copy để sao chép format

Format kết quả: `KWM - [Nguồn Khách] - [Kênh Tương Tác] | [Ghi chú]`

### Các format khác (KWC, KLM, KLC)
1. Chọn loại tương ứng ở Field 1
2. Nhập ghi chú (nếu cần)
3. Nhấn Copy để sao chép format

Format kết quả: `[Loại] | [Ghi chú]`

## Cấu trúc dự án

```
├── manifest.json      # Cấu hình extension
├── popup.html        # Giao diện người dùng
├── popup.css         # Style cho giao diện
├── popup.js          # Logic xử lý
└── images/           # Thư mục chứa icons
    ├── icon16.png
    ├── icon32.png
    ├── icon48.png
    ├── icon128.png
    └── logo.png
```

## Yêu cầu

- Chrome Browser
- Quyền truy cập clipboard
- Quyền activeTab

## Đóng góp

Mọi đóng góp đều được hoan nghênh! Vui lòng:
1. Fork dự án
2. Tạo branch mới (`git checkout -b feature/AmazingFeature`)
3. Commit thay đổi (`git commit -m 'Add some AmazingFeature'`)
4. Push lên branch (`git push origin feature/AmazingFeature`)
5. Tạo Pull Request

## License

MIT License - Xem file [LICENSE](LICENSE) để biết thêm chi tiết. 