document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('copyButton').addEventListener('click', copyText);
    handleField1Change(); // Khởi tạo trạng thái khi tải trang
});

function handleField1Change() {
    const field1 = document.getElementById('field1').value;
    const isKWM = (field1 === 'KWM');
    
    const field2 = document.getElementById('field2');
    const field3 = document.getElementById('field3');

    if (isKWM) {
        field2.disabled = false;
        field3.disabled = false;
    } else {
        field2.disabled = true;
        field3.disabled = true;
        field2.value = ""; // Xóa giá trị hiện tại
        field3.value = ""; // Xóa giá trị hiện tại
    }
}

function copyText() {
    const field1 = document.getElementById('field1').value;
    const field2 = document.getElementById('field2').value;
    const field3 = document.getElementById('field3').value;
    const note = document.getElementById('note').value;
    
    let textToCopy = field1;
    
    if (field1 === 'KWM') {
        textToCopy += ` - ${field2} - ${field3}`;
    }
    
    textToCopy += ` | ${note}`;

    navigator.clipboard.writeText(textToCopy).then(() => {
        alert('Đã sao chép: ' + textToCopy);
    }).catch(err => {
        console.error('Không thể sao chép', err);
    });
}